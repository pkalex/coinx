module.exports = {
  mongoURI: "mongodb://akmalu21:Aralogan12358!@ds253879.mlab.com:53879/coinoid",
  secretOrKey: "secret"
};
