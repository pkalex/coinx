import React, { Component } from "react";
import axios from "axios";
var NumberFormat = require("react-number-format");

class Playground extends Component {
  constructor(props) {
    super(props);

    this.state = {
      cryptos: []
    };
  }

  componentDidMount() {
    axios
      .get(
        "https://min-api.cryptocompare.com/data/pricemulti?fsyms=BTC,ETH,EOS&tsyms=USD"
      )
      .then(res => {
        const cryptos = res.data;
        console.log(cryptos);
        this.setState({ cryptos: cryptos });
      });
  }

  render() {
    return (
      <div className="playground">
        <div className="container">
          <div className="row">
            <div className="col-md-8 m-auto">
              <h1 className="display-4 text-center">Playground</h1>
              {Object.keys(this.state.cryptos).map(key => (
                <div id="crypto-container">
                  <span className="left">{key}</span>
                  <span className="right">
                    <NumberFormat
                      value={this.state.cryptos[key].USD}
                      displayType={"text"}
                      decimalPrecision={2}
                      thousandSeparator={true}
                      prefix={"$"}
                    />
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default Playground;
